"""Model bundle discovery and download helpers."""

from __future__ import annotations

import hashlib
import os
import shutil
import stat
import sys
import tarfile
import tempfile
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from huggingface_hub import snapshot_download

from ._version import __version__ as SDK_VERSION
from .exceptions import ConfigurationError, DownloadError, ModelNotFoundError

DEFAULT_MODEL_ID = "blitz-tts-2"
MODEL_REPO_ENV_VAR = "BLITZ_TTS_HF_REPO_ID"
MODEL_REVISION_ENV_VAR = "BLITZ_TTS_MODEL_REVISION"
GITHUB_RELEASES_REPO_ENV_VAR = "BLITZ_TTS_GITHUB_RELEASES_REPO"
MODEL_ENV_VAR = "BLITZ_TTS_MODEL_DIR"
MODEL_BUNDLE_URL_ENV_VAR = "BLITZ_TTS_MODEL_BUNDLE_URL"
MODEL_BUNDLE_SHA256_ENV_VAR = "BLITZ_TTS_MODEL_BUNDLE_SHA256"
MODEL_BUNDLE_SHA256_URL_ENV_VAR = "BLITZ_TTS_MODEL_BUNDLE_SHA256_URL"
HF_TOKEN_ENV_VARS = ("HF_TOKEN", "HUGGINGFACE_HUB_TOKEN")
DEFAULT_GITHUB_RELEASES_REPO = os.environ.get(
    GITHUB_RELEASES_REPO_ENV_VAR,
    "sid-2209/blitz-tts",
)
DEFAULT_REPO_ID = os.environ.get(MODEL_REPO_ENV_VAR, "arth22/blitz-tts")
DEFAULT_RELEASE_TAG = f"py-v{SDK_VERSION}"
DEFAULT_MODEL_REVISION = os.environ.get(MODEL_REVISION_ENV_VAR, DEFAULT_RELEASE_TAG)
GITHUB_RELEASES_BASE_URL = f"https://github.com/{DEFAULT_GITHUB_RELEASES_REPO}/releases/download"
DEFAULT_BUNDLE_FILENAME = f"blitz_tts_assets-{DEFAULT_MODEL_ID}.tar.gz"
DEFAULT_BUNDLE_SHA256_FILENAME = f"{DEFAULT_BUNDLE_FILENAME}.sha256"
DEFAULT_BUNDLE_URL = f"{GITHUB_RELEASES_BASE_URL}/{DEFAULT_RELEASE_TAG}/{DEFAULT_BUNDLE_FILENAME}"
DEFAULT_BUNDLE_SHA256_URL = (
    f"{GITHUB_RELEASES_BASE_URL}/{DEFAULT_RELEASE_TAG}/{DEFAULT_BUNDLE_SHA256_FILENAME}"
)

REQUIRED_ONNX_FILES = (
    "duration_predictor.onnx",
    "text_encoder.onnx",
    "tts.json",
    "unicode_indexer.json",
    "vector_estimator.onnx",
    "vocoder.onnx",
)


@dataclass(frozen=True)
class ModelBundle:
    """Resolved asset bundle containing ONNX files and voice styles."""

    assets_dir: Path

    @property
    def onnx_dir(self) -> Path:
        return self.assets_dir / "onnx"

    @property
    def voice_styles_dir(self) -> Path:
        return self.assets_dir / "voice_styles"


def default_cache_dir() -> Path:
    """Return the default cache directory for downloaded assets."""

    if sys.platform == "darwin":
        return Path.home() / "Library" / "Caches" / "blitz_tts"

    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA")
        if root:
            return Path(root) / "blitz_tts"
        return Path.home() / "AppData" / "Local" / "blitz_tts"

    root = os.environ.get("XDG_CACHE_HOME")
    if root:
        return Path(root) / "blitz_tts"
    return Path.home() / ".cache" / "blitz_tts"


def _cache_path(cache_dir: str | os.PathLike[str] | None = None) -> Path:
    return Path(cache_dir).expanduser().resolve() if cache_dir else default_cache_dir()


def installed_assets_dir(
    *,
    model: str = DEFAULT_MODEL_ID,
    cache_dir: str | os.PathLike[str] | None = None,
) -> Path:
    """Return the stable path used for offline-installed assets."""

    return _cache_path(cache_dir) / "installed_assets" / model


def _normalize_assets_dir(path: Path) -> Path:
    path = path.expanduser().resolve()

    if path.name == "onnx" and (path.parent / "voice_styles").is_dir():
        return path.parent

    if path.name == "voice_styles" and (path.parent / "onnx").is_dir():
        return path.parent

    return path


def is_valid_assets_dir(path: Path) -> bool:
    """Return True when the candidate directory looks like a model bundle."""

    path = _normalize_assets_dir(path)
    onnx_dir = path / "onnx"
    voice_styles_dir = path / "voice_styles"

    if not onnx_dir.is_dir() or not voice_styles_dir.is_dir():
        return False

    for file_name in REQUIRED_ONNX_FILES:
        if not (onnx_dir / file_name).is_file():
            return False

    return any(voice_styles_dir.glob("*.json"))


def _candidate_paths(
    *,
    model: str = DEFAULT_MODEL_ID,
    cache_dir: str | os.PathLike[str] | None = None,
) -> Iterable[Path]:
    env_path = os.environ.get(MODEL_ENV_VAR)
    if env_path:
        yield Path(env_path)

    cwd = Path.cwd()
    yield cwd / "assets"
    yield cwd / "BlitzTTS" / "assets"

    yield installed_assets_dir(model=model, cache_dir=cache_dir)

    package_assets = Path(__file__).resolve().parents[3] / "assets"
    yield package_assets


def _resolve_repo_id(repo_id: str | None = None) -> str:
    return repo_id or os.environ.get(MODEL_REPO_ENV_VAR) or DEFAULT_REPO_ID


def _resolve_model_revision(model_revision: str | None = None) -> str | None:
    return model_revision or os.environ.get(MODEL_REVISION_ENV_VAR) or DEFAULT_MODEL_REVISION


def _resolve_auth_token(token: str | None = None) -> str | None:
    if token:
        return token

    for env_var in HF_TOKEN_ENV_VARS:
        env_value = os.environ.get(env_var)
        if env_value:
            return env_value

    return None


def _resolve_configured_bundle_url(bundle_url: str | None = None) -> str | None:
    return bundle_url or os.environ.get(MODEL_BUNDLE_URL_ENV_VAR)


def _resolve_configured_bundle_sha256(bundle_sha256: str | None = None) -> str | None:
    return bundle_sha256 or os.environ.get(MODEL_BUNDLE_SHA256_ENV_VAR)


def _resolve_configured_bundle_sha256_url(bundle_sha256_url: str | None = None) -> str | None:
    return bundle_sha256_url or os.environ.get(MODEL_BUNDLE_SHA256_URL_ENV_VAR)


def _normalize_sha256(bundle_sha256: str | None) -> str | None:
    if bundle_sha256 is None:
        return None

    normalized = bundle_sha256.strip().lower()
    if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
        raise ConfigurationError(
            "bundle_sha256 must be a 64-character hexadecimal SHA256 digest."
        )

    return normalized


def _sha256_for_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as input_file:
        for chunk in iter(lambda: input_file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_relative_to(path: Path, directory: Path) -> bool:
    try:
        path.relative_to(directory)
    except ValueError:
        return False
    return True


def _validate_extract_path(destination: Path, member_name: str) -> None:
    root = destination.resolve()
    target = (root / member_name).resolve()
    if not _is_relative_to(target, root):
        raise DownloadError("Asset archive contains unsafe paths and cannot be extracted.")


def _extract_zip_archive(archive_path: Path, destination: Path) -> None:
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            _validate_extract_path(destination, member.filename)
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise DownloadError("Asset archive contains symbolic links, which are not supported.")
        archive.extractall(destination)


def _extract_tar_archive(archive_path: Path, destination: Path) -> None:
    with tarfile.open(archive_path, "r:*") as archive:
        for member in archive.getmembers():
            _validate_extract_path(destination, member.name)
            if member.issym() or member.islnk():
                raise DownloadError("Asset archive contains symbolic links, which are not supported.")
        archive.extractall(destination)


def _extract_archive(archive_path: Path, destination: Path) -> None:
    if zipfile.is_zipfile(archive_path):
        _extract_zip_archive(archive_path, destination)
        return

    if tarfile.is_tarfile(archive_path):
        _extract_tar_archive(archive_path, destination)
        return

    raise DownloadError(
        f"Unsupported asset archive format '{archive_path.name}'. "
        "Use a .zip, .tar, or .tar.gz bundle."
    )


def _find_assets_dir(root: Path) -> Path | None:
    queue = [root]
    visited: set[Path] = set()

    while queue:
        current = queue.pop(0)
        normalized = _normalize_assets_dir(current)
        if normalized in visited:
            continue

        visited.add(normalized)
        if is_valid_assets_dir(normalized):
            return normalized

        for child in current.iterdir():
            if child.is_dir():
                queue.append(child)

    return None


def _bundle_cache_dir(
    *,
    model: str,
    cache_dir: str | os.PathLike[str] | None,
    bundle_url: str,
    cache_hint: str | None,
) -> Path:
    cache_key = hashlib.sha256(
        f"{model}\0{bundle_url}\0{cache_hint or ''}".encode("utf-8")
    ).hexdigest()[:24]
    return _cache_path(cache_dir) / "bundles" / model / cache_key


def _cached_archive_bundle(
    *,
    model: str,
    cache_dir: str | os.PathLike[str] | None,
    bundle_url: str,
    cache_hint: str | None,
) -> ModelBundle | None:
    cached_dir = _bundle_cache_dir(
        model=model,
        cache_dir=cache_dir,
        bundle_url=bundle_url,
        cache_hint=cache_hint,
    )
    if is_valid_assets_dir(cached_dir):
        return ModelBundle(cached_dir)
    return None


def _local_file_path(location: str) -> Path | None:
    parsed = urllib.parse.urlparse(location)
    if parsed.scheme == "":
        return Path(location).expanduser().resolve()
    if parsed.scheme == "file":
        return Path(urllib.request.url2pathname(parsed.path)).expanduser().resolve()
    return None


def _download_text_file(
    *,
    url: str,
    token: str | None = None,
) -> str:
    local_path = _local_file_path(url)
    if local_path is not None:
        if not local_path.is_file():
            raise DownloadError(f"Bundle checksum file not found: {local_path}")
        return local_path.read_text(encoding="utf-8")

    request_headers = {}
    auth_token = _resolve_auth_token(token)
    if auth_token:
        request_headers["Authorization"] = f"Bearer {auth_token}"

    request = urllib.request.Request(url, headers=request_headers)
    try:
        with urllib.request.urlopen(request) as response:
            return response.read().decode("utf-8")
    except Exception as exc:  # pragma: no cover - exercised in live environments
        raise DownloadError(f"Failed to download BlitzTTS checksum file from '{url}'.") from exc


def _sha256_from_text(contents: str) -> str:
    for token in contents.replace("\n", " ").split():
        normalized = token.strip().lower()
        if len(normalized) == 64 and all(ch in "0123456789abcdef" for ch in normalized):
            return normalized

    raise DownloadError("Could not parse a SHA256 digest from the provided checksum file.")


def _resolve_archive_sha256(
    *,
    bundle_sha256: str | None,
    bundle_sha256_url: str | None,
    token: str | None = None,
) -> str | None:
    normalized_sha256 = _normalize_sha256(bundle_sha256)
    if normalized_sha256 is not None:
        return normalized_sha256

    if bundle_sha256_url is None:
        return None

    checksum_text = _download_text_file(url=bundle_sha256_url, token=token)
    return _sha256_from_text(checksum_text)


def _download_bundle_archive(
    *,
    bundle_url: str,
    destination: Path,
    token: str | None = None,
) -> None:
    local_path = _local_file_path(bundle_url)
    if local_path is not None:
        if not local_path.is_file():
            raise DownloadError(f"Bundle archive not found: {local_path}")
        shutil.copy2(local_path, destination)
        return

    request_headers = {}
    auth_token = _resolve_auth_token(token)
    if auth_token:
        request_headers["Authorization"] = f"Bearer {auth_token}"

    request = urllib.request.Request(bundle_url, headers=request_headers)
    try:
        with urllib.request.urlopen(request) as response, destination.open("wb") as output_file:
            shutil.copyfileobj(response, output_file)
    except Exception as exc:  # pragma: no cover - exercised in live environments
        raise DownloadError(f"Failed to download BlitzTTS asset bundle from '{bundle_url}'.") from exc


def _download_archive_bundle(
    *,
    model: str,
    bundle_url: str,
    bundle_sha256: str | None,
    bundle_sha256_url: str | None = None,
    cache_dir: str | os.PathLike[str] | None = None,
    token: str | None = None,
) -> ModelBundle:
    cache_hint = bundle_sha256 or bundle_sha256_url
    normalized_sha256 = _resolve_archive_sha256(
        bundle_sha256=bundle_sha256,
        bundle_sha256_url=bundle_sha256_url,
        token=token,
    )
    cached_bundle = _cached_archive_bundle(
        model=model,
        cache_dir=cache_dir,
        bundle_url=bundle_url,
        cache_hint=cache_hint,
    )
    if cached_bundle is not None:
        return cached_bundle

    target_dir = _bundle_cache_dir(
        model=model,
        cache_dir=cache_dir,
        bundle_url=bundle_url,
        cache_hint=cache_hint,
    )
    target_dir.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="blitz-tts-", dir=str(target_dir.parent)) as temp_dir:
        temp_root = Path(temp_dir)
        archive_path = temp_root / "bundle.archive"
        extract_dir = temp_root / "extract"
        staged_dir = temp_root / "assets"

        _download_bundle_archive(bundle_url=bundle_url, destination=archive_path, token=token)

        actual_sha256 = _sha256_for_file(archive_path)
        if normalized_sha256 and actual_sha256 != normalized_sha256:
            raise DownloadError(
                "Downloaded BlitzTTS asset bundle failed checksum verification. "
                f"Expected {normalized_sha256}, got {actual_sha256}."
            )

        extract_dir.mkdir()
        _extract_archive(archive_path, extract_dir)

        assets_dir = _find_assets_dir(extract_dir)
        if assets_dir is None:
            raise DownloadError(
                f"Downloaded BlitzTTS asset bundle from '{bundle_url}' but the bundle is incomplete."
            )

        shutil.copytree(assets_dir, staged_dir)

        if target_dir.exists():
            if is_valid_assets_dir(target_dir):
                return ModelBundle(target_dir)
            shutil.rmtree(target_dir)

        shutil.move(str(staged_dir), str(target_dir))

    return ModelBundle(target_dir)


def download_model_bundle(
    *,
    model: str = DEFAULT_MODEL_ID,
    repo_id: str | None = DEFAULT_REPO_ID,
    model_revision: str | None = DEFAULT_MODEL_REVISION,
    cache_dir: str | os.PathLike[str] | None = None,
    token: str | None = None,
    bundle_url: str | None = None,
    bundle_sha256: str | None = None,
    bundle_sha256_url: str | None = None,
) -> ModelBundle:
    """Download a BlitzTTS asset bundle into the cache."""

    resolved_repo_id = _resolve_repo_id(repo_id)
    resolved_model_revision = _resolve_model_revision(model_revision)
    configured_bundle_url = _resolve_configured_bundle_url(bundle_url)
    configured_bundle_sha256 = _resolve_configured_bundle_sha256(bundle_sha256)
    configured_bundle_sha256_url = _resolve_configured_bundle_sha256_url(bundle_sha256_url)

    if configured_bundle_url:
        return _download_archive_bundle(
            model=model,
            bundle_url=configured_bundle_url,
            bundle_sha256=configured_bundle_sha256,
            bundle_sha256_url=configured_bundle_sha256_url,
            cache_dir=cache_dir,
            token=token,
        )

    cache_path = _cache_path(cache_dir)
    auth_token = _resolve_auth_token(token)

    try:
        snapshot_path = Path(
            snapshot_download(
                repo_id=resolved_repo_id,
                cache_dir=str(cache_path),
                revision=resolved_model_revision,
                allow_patterns=["onnx/*", "voice_styles/*"],
                token=auth_token,
            )
        ).resolve()
    except Exception as exc:  # pragma: no cover - exercised in live environments
        revision_note = (
            f" at revision '{resolved_model_revision}'" if resolved_model_revision else ""
        )
        raise DownloadError(
            f"Failed to download BlitzTTS assets from '{resolved_repo_id}'{revision_note}. "
            "Pass bundle_url=..., bundle_sha256=..., or bundle_sha256_url=... for a direct archive, "
            "or if the repository is private or gated, pass token=..., set HF_TOKEN/HUGGINGFACE_HUB_TOKEN, "
            "or use model_dir=... with a local asset bundle."
        ) from exc

    bundle = ModelBundle(snapshot_path)
    if not is_valid_assets_dir(bundle.assets_dir):
        raise DownloadError(
            f"Downloaded assets from '{resolved_repo_id}' but the bundle is incomplete."
        )
    return bundle


def resolve_model_bundle(
    *,
    model: str = DEFAULT_MODEL_ID,
    model_dir: str | os.PathLike[str] | None = None,
    auto_download: bool = True,
    repo_id: str | None = DEFAULT_REPO_ID,
    model_revision: str | None = DEFAULT_MODEL_REVISION,
    cache_dir: str | os.PathLike[str] | None = None,
    token: str | None = None,
    bundle_url: str | None = None,
    bundle_sha256: str | None = None,
    bundle_sha256_url: str | None = None,
) -> ModelBundle:
    """Resolve a usable model bundle from disk or download it on demand."""

    configured_bundle_url = _resolve_configured_bundle_url(bundle_url)
    configured_bundle_sha256 = _resolve_configured_bundle_sha256(bundle_sha256)
    configured_bundle_sha256_url = _resolve_configured_bundle_sha256_url(bundle_sha256_url)

    if model_dir is not None:
        candidate = _normalize_assets_dir(Path(model_dir))
        if is_valid_assets_dir(candidate):
            return ModelBundle(candidate)
        raise ModelNotFoundError(
            f"Model directory '{candidate}' does not contain a valid BlitzTTS asset bundle."
        )

    if configured_bundle_url:
        cached_bundle = _cached_archive_bundle(
            model=model,
            cache_dir=cache_dir,
            bundle_url=configured_bundle_url,
            cache_hint=configured_bundle_sha256 or configured_bundle_sha256_url,
        )
        if cached_bundle is not None:
            return cached_bundle

        if auto_download:
            return download_model_bundle(
                model=model,
                repo_id=repo_id,
                model_revision=model_revision,
                cache_dir=cache_dir,
                token=token,
                bundle_url=configured_bundle_url,
                bundle_sha256=configured_bundle_sha256,
                bundle_sha256_url=configured_bundle_sha256_url,
            )

        raise ModelNotFoundError(
            "Could not find BlitzTTS assets for the configured bundle_url in the local cache. "
            "Enable auto_download, provide model_dir, or populate the cache first."
        )

    for candidate in _candidate_paths(model=model, cache_dir=cache_dir):
        normalized = _normalize_assets_dir(candidate)
        if is_valid_assets_dir(normalized):
            return ModelBundle(normalized)

    if auto_download:
        return download_model_bundle(
            model=model,
            repo_id=repo_id,
            model_revision=model_revision,
            cache_dir=cache_dir,
            token=token,
            bundle_url=configured_bundle_url,
            bundle_sha256=configured_bundle_sha256,
            bundle_sha256_url=configured_bundle_sha256_url,
        )

    raise ModelNotFoundError(
        "Could not find BlitzTTS assets locally. "
        "Provide 'model_dir', configure bundle_url, or initialize TTS with auto_download=True."
    )
