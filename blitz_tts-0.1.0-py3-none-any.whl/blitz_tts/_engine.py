"""Internal ONNX inference engine used by the public SDK."""

from __future__ import annotations

import json
import logging
import os
import re
import time
import unicodedata
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence

import numpy as np
import onnxruntime as ort

from .exceptions import ConfigurationError, ValidationError

logger = logging.getLogger(__name__)

AVAILABLE_LANGS = ("en", "ko", "es", "pt", "fr")

EMOJI_PATTERN = re.compile(
    "[\U0001f600-\U0001f64f"
    "\U0001f300-\U0001f5ff"
    "\U0001f680-\U0001f6ff"
    "\U0001f700-\U0001f77f"
    "\U0001f780-\U0001f7ff"
    "\U0001f800-\U0001f8ff"
    "\U0001f900-\U0001f9ff"
    "\U0001fa00-\U0001fa6f"
    "\U0001fa70-\U0001faff"
    "\u2600-\u26ff"
    "\u2700-\u27bf"
    "\U0001f1e6-\U0001f1ff]+",
    flags=re.UNICODE,
)

SYMBOL_REPLACEMENTS = {
    "–": "-",
    "‑": "-",
    "—": "-",
    "_": " ",
    "\u201c": '"',
    "\u201d": '"',
    "\u2018": "'",
    "\u2019": "'",
    "´": "'",
    "`": "'",
    "[": " ",
    "]": " ",
    "|": " ",
    "/": " ",
    "#": " ",
    "→": " ",
    "←": " ",
    "€": " euros ",
    "£": " pounds ",
    "¥": " yen ",
    "₹": " rupees ",
    "&": " and ",
    "+": " plus ",
    "%": " percent ",
}

EXPRESSION_REPLACEMENTS = {
    "@": " at ",
    "e.g.,": "for example, ",
    "i.e.,": "that is, ",
}

END_PUNCTUATION_PATTERN = re.compile(r"[.!?;:,'\"')\]}…。」』】〉》›»]$")


@contextmanager
def timer(name: str):
    """Simple timing helper used by examples and manual profiling."""

    start = time.time()
    logger.info("%s...", name)
    try:
        yield
    finally:
        logger.info("%s completed in %.2f sec", name, time.time() - start)


def sanitize_filename(text: str, max_len: int) -> str:
    """Return a filesystem-friendly filename prefix."""

    prefix = text[:max_len]
    return re.sub(r"[^\w]", "_", prefix, flags=re.UNICODE)


def chunk_text(text: str, max_len: int = 300) -> list[str]:
    """Split long text into sentence-aware chunks."""

    paragraphs = [p.strip() for p in re.split(r"\n\s*\n+", text.strip()) if p.strip()]
    chunks: list[str] = []

    for paragraph in paragraphs:
        pattern = (
            r"(?<!Mr\.)(?<!Mrs\.)(?<!Ms\.)(?<!Dr\.)(?<!Prof\.)(?<!Sr\.)"
            r"(?<!Jr\.)(?<!Ph\.D\.)(?<!etc\.)(?<!e\.g\.)(?<!i\.e\.)"
            r"(?<!vs\.)(?<!Inc\.)(?<!Ltd\.)(?<!Co\.)(?<!Corp\.)(?<!St\.)"
            r"(?<!Ave\.)(?<!Blvd\.)(?<!\b[A-Z]\.)(?<=[.!?])\s+"
        )
        sentences = re.split(pattern, paragraph)
        current_chunk = ""

        for sentence in sentences:
            candidate = f"{current_chunk} {sentence}".strip() if current_chunk else sentence
            if len(candidate) <= max_len:
                current_chunk = candidate
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence.strip()

        if current_chunk:
            chunks.append(current_chunk.strip())

    return chunks or [text.strip()]


class UnicodeProcessor:
    """Prepare user text for the ONNX text encoder."""

    def __init__(self, unicode_indexer: str | os.PathLike[str] | Sequence[int]):
        if isinstance(unicode_indexer, (str, os.PathLike, Path)):
            with open(unicode_indexer, "r", encoding="utf-8") as file:
                self.indexer = json.load(file)
        else:
            self.indexer = list(unicode_indexer)

        if len(self.indexer) < 128:
            raise ConfigurationError("Unicode indexer must contain the model token table.")

        self._space_token = self.indexer[ord(" ")] if self.indexer[ord(" ")] >= 0 else 0

    def _is_supported_char(self, char: str) -> bool:
        codepoint = ord(char)
        if codepoint >= len(self.indexer):
            return False
        return self.indexer[codepoint] >= 0

    def _replace_unsupported_characters(self, text: str) -> str:
        sanitized: list[str] = []
        last_was_space = False

        for char in text:
            if char.isspace():
                if sanitized and not last_was_space:
                    sanitized.append(" ")
                last_was_space = True
                continue

            if self._is_supported_char(char):
                sanitized.append(char)
                last_was_space = False
                continue

            if unicodedata.category(char) == "Mn":
                continue

            if sanitized and not last_was_space:
                sanitized.append(" ")
                last_was_space = True

        return "".join(sanitized)

    def preprocess_text(self, text: str, lang: str) -> str:
        """Normalize user text into the model's tagged input format."""

        if lang not in AVAILABLE_LANGS:
            raise ValidationError(
                f"Invalid language '{lang}'. Available languages: {', '.join(AVAILABLE_LANGS)}."
            )

        text = unicodedata.normalize("NFKD", text)
        text = EMOJI_PATTERN.sub("", text)

        for source, target in SYMBOL_REPLACEMENTS.items():
            text = text.replace(source, target)

        text = re.sub(r"[♥☆♡©\\]", "", text)

        for source, target in EXPRESSION_REPLACEMENTS.items():
            text = text.replace(source, target)

        text = re.sub(r" ,", ",", text)
        text = re.sub(r" \.", ".", text)
        text = re.sub(r" !", "!", text)
        text = re.sub(r" \?", "?", text)
        text = re.sub(r" ;", ";", text)
        text = re.sub(r" :", ":", text)
        text = re.sub(r" '", "'", text)
        text = re.sub(r'""+', '"', text)
        text = re.sub(r"''+", "'", text)
        text = re.sub(r"`{2,}", "`", text)

        text = self._replace_unsupported_characters(text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            raise ValidationError("Input text is empty after normalization.")

        if not END_PUNCTUATION_PATTERN.search(text):
            text += "."

        tagged_text = f"<{lang}>{text}</{lang}>"
        tagged_text = self._replace_unsupported_characters(tagged_text)
        tagged_text = re.sub(r"\s+", " ", tagged_text).strip()
        if not tagged_text:
            raise ValidationError("Input text became empty after language tagging.")

        return tagged_text

    def _text_to_token_ids(self, text: str) -> np.ndarray:
        token_ids: list[int] = []

        for char in text:
            codepoint = ord(char)
            if codepoint >= len(self.indexer):
                token_ids.append(self._space_token)
                continue

            token_id = self.indexer[codepoint]
            if token_id < 0:
                token_id = self._space_token
            token_ids.append(token_id)

        return np.asarray(token_ids, dtype=np.int64)

    def __call__(
        self, text_list: Sequence[str], lang_list: Sequence[str]
    ) -> tuple[np.ndarray, np.ndarray]:
        if len(text_list) != len(lang_list):
            raise ValidationError("text_list and lang_list must have the same length.")

        processed_texts = [
            self.preprocess_text(text, lang) for text, lang in zip(text_list, lang_list)
        ]
        text_lengths = np.asarray([len(text) for text in processed_texts], dtype=np.int64)
        text_ids = np.zeros((len(processed_texts), int(text_lengths.max())), dtype=np.int64)

        for row_index, text in enumerate(processed_texts):
            token_ids = self._text_to_token_ids(text)
            text_ids[row_index, : len(token_ids)] = token_ids

        text_mask = length_to_mask(text_lengths)
        return text_ids, text_mask


@dataclass
class StyleTensor:
    ttl: np.ndarray
    dp: np.ndarray


class InferenceEngine:
    """Low-level ONNX inference wrapper."""

    def __init__(
        self,
        cfgs: dict,
        text_processor: UnicodeProcessor,
        dp_ort: ort.InferenceSession,
        text_enc_ort: ort.InferenceSession,
        vector_est_ort: ort.InferenceSession,
        vocoder_ort: ort.InferenceSession,
    ):
        self.cfgs = cfgs
        self.text_processor = text_processor
        self.dp_ort = dp_ort
        self.text_enc_ort = text_enc_ort
        self.vector_est_ort = vector_est_ort
        self.vocoder_ort = vocoder_ort
        self.sample_rate = cfgs["ae"]["sample_rate"]
        self.base_chunk_size = cfgs["ae"]["base_chunk_size"]
        self.chunk_compress_factor = cfgs["ttl"]["chunk_compress_factor"]
        self.latent_dim = cfgs["ttl"]["latent_dim"]

    def sample_noisy_latent(
        self, duration: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        batch_size = len(duration)
        wav_len_max = float(duration.max()) * self.sample_rate
        wav_lengths = (duration * self.sample_rate).astype(np.int64)
        chunk_size = self.base_chunk_size * self.chunk_compress_factor
        latent_len = int((wav_len_max + chunk_size - 1) / chunk_size)
        latent_dim = self.latent_dim * self.chunk_compress_factor

        noisy_latent = np.random.randn(batch_size, latent_dim, latent_len).astype(np.float32)
        latent_mask = get_latent_mask(
            wav_lengths,
            self.base_chunk_size,
            self.chunk_compress_factor,
        )
        noisy_latent = noisy_latent * latent_mask
        return noisy_latent, latent_mask

    def _infer(
        self,
        text_list: Sequence[str],
        lang_list: Sequence[str],
        style: StyleTensor,
        total_step: int,
        speed: float = 1.05,
    ) -> tuple[np.ndarray, np.ndarray]:
        if len(text_list) != int(style.ttl.shape[0]):
            raise ValidationError(
                "Number of texts must match the number of voice styles for inference."
            )

        batch_size = len(text_list)
        text_ids, text_mask = self.text_processor(text_list, lang_list)

        durations, *_ = self.dp_ort.run(
            None,
            {"text_ids": text_ids, "style_dp": style.dp, "text_mask": text_mask},
        )
        durations = durations / speed

        text_embeddings, *_ = self.text_enc_ort.run(
            None,
            {"text_ids": text_ids, "style_ttl": style.ttl, "text_mask": text_mask},
        )

        xt, latent_mask = self.sample_noisy_latent(durations)
        total_step_np = np.asarray([total_step] * batch_size, dtype=np.float32)

        for step in range(total_step):
            current_step = np.asarray([step] * batch_size, dtype=np.float32)
            xt, *_ = self.vector_est_ort.run(
                None,
                {
                    "noisy_latent": xt,
                    "text_emb": text_embeddings,
                    "style_ttl": style.ttl,
                    "text_mask": text_mask,
                    "latent_mask": latent_mask,
                    "current_step": current_step,
                    "total_step": total_step_np,
                },
            )

        wav, *_ = self.vocoder_ort.run(None, {"latent": xt})
        return wav, durations

    def __call__(
        self,
        text: str,
        lang: str,
        style: StyleTensor,
        total_step: int,
        speed: float = 1.05,
        silence_duration: float = 0.3,
    ) -> tuple[np.ndarray, np.ndarray]:
        if int(style.ttl.shape[0]) != 1:
            raise ValidationError("Single synthesis expects exactly one voice style.")

        max_len = 120 if lang == "ko" else 300
        text_chunks = chunk_text(text, max_len=max_len)
        wav_cat: Optional[np.ndarray] = None
        dur_cat: Optional[np.ndarray] = None

        for text_chunk in text_chunks:
            wav, durations = self._infer([text_chunk], [lang], style, total_step, speed)
            if wav_cat is None:
                wav_cat = wav
                dur_cat = durations
                continue

            silence = np.zeros((1, int(silence_duration * self.sample_rate)), dtype=np.float32)
            wav_cat = np.concatenate([wav_cat, silence, wav], axis=1)
            dur_cat = dur_cat + durations + silence_duration

        if wav_cat is None or dur_cat is None:  # pragma: no cover - guarded by validation
            raise ValidationError("No audio was generated from the provided text.")

        return wav_cat, dur_cat

    def batch(
        self,
        text_list: Sequence[str],
        lang_list: Sequence[str],
        style: StyleTensor,
        total_step: int,
        speed: float = 1.05,
    ) -> tuple[np.ndarray, np.ndarray]:
        return self._infer(text_list, lang_list, style, total_step, speed)


def length_to_mask(lengths: np.ndarray, max_len: Optional[int] = None) -> np.ndarray:
    max_len = max_len or int(lengths.max())
    ids = np.arange(0, max_len)
    mask = (ids < np.expand_dims(lengths, axis=1)).astype(np.float32)
    return mask.reshape(-1, 1, max_len)


def get_latent_mask(
    wav_lengths: np.ndarray, base_chunk_size: int, chunk_compress_factor: int
) -> np.ndarray:
    latent_size = base_chunk_size * chunk_compress_factor
    latent_lengths = (wav_lengths + latent_size - 1) // latent_size
    return length_to_mask(latent_lengths)


def load_onnx(
    onnx_path: str | os.PathLike[str],
    opts: ort.SessionOptions,
    providers: Sequence[str],
) -> ort.InferenceSession:
    return ort.InferenceSession(str(onnx_path), sess_options=opts, providers=list(providers))


def load_onnx_all(
    onnx_dir: str | os.PathLike[str],
    opts: ort.SessionOptions,
    providers: Sequence[str],
) -> tuple[
    ort.InferenceSession,
    ort.InferenceSession,
    ort.InferenceSession,
    ort.InferenceSession,
]:
    onnx_root = Path(onnx_dir)
    dp_onnx_path = onnx_root / "duration_predictor.onnx"
    text_enc_onnx_path = onnx_root / "text_encoder.onnx"
    vector_est_onnx_path = onnx_root / "vector_estimator.onnx"
    vocoder_onnx_path = onnx_root / "vocoder.onnx"

    dp_ort = load_onnx(dp_onnx_path, opts, providers)
    text_enc_ort = load_onnx(text_enc_onnx_path, opts, providers)
    vector_est_ort = load_onnx(vector_est_onnx_path, opts, providers)
    vocoder_ort = load_onnx(vocoder_onnx_path, opts, providers)
    return dp_ort, text_enc_ort, vector_est_ort, vocoder_ort


def load_cfgs(onnx_dir: str | os.PathLike[str]) -> dict:
    cfg_path = Path(onnx_dir) / "tts.json"
    with open(cfg_path, "r", encoding="utf-8") as file:
        return json.load(file)


def load_text_processor(onnx_dir: str | os.PathLike[str]) -> UnicodeProcessor:
    unicode_indexer_path = Path(onnx_dir) / "unicode_indexer.json"
    return UnicodeProcessor(unicode_indexer_path)


def load_text_to_speech_engine(
    onnx_dir: str | os.PathLike[str],
    providers: Sequence[str] | None = None,
) -> InferenceEngine:
    opts = ort.SessionOptions()
    selected_providers = list(providers) if providers is not None else ["CPUExecutionProvider"]
    available_providers = set(ort.get_available_providers())
    missing = [provider for provider in selected_providers if provider not in available_providers]
    if missing:
        raise ConfigurationError(
            "Requested ONNX Runtime providers are not available: "
            + ", ".join(missing)
        )

    logger.info("Using providers: %s", ", ".join(selected_providers))
    cfgs = load_cfgs(onnx_dir)
    dp_ort, text_enc_ort, vector_est_ort, vocoder_ort = load_onnx_all(
        onnx_dir, opts, selected_providers
    )
    text_processor = load_text_processor(onnx_dir)
    return InferenceEngine(
        cfgs,
        text_processor,
        dp_ort,
        text_enc_ort,
        vector_est_ort,
        vocoder_ort,
    )


def load_voice_style_tensors(
    voice_style_paths: Sequence[str | os.PathLike[str]],
) -> StyleTensor:
    if not voice_style_paths:
        raise ValidationError("At least one voice style path must be provided.")

    with open(voice_style_paths[0], "r", encoding="utf-8") as file:
        first_style = json.load(file)

    batch_size = len(voice_style_paths)
    ttl_dims = first_style["style_ttl"]["dims"]
    dp_dims = first_style["style_dp"]["dims"]

    ttl_style = np.zeros([batch_size, ttl_dims[1], ttl_dims[2]], dtype=np.float32)
    dp_style = np.zeros([batch_size, dp_dims[1], dp_dims[2]], dtype=np.float32)

    for index, voice_style_path in enumerate(voice_style_paths):
        with open(voice_style_path, "r", encoding="utf-8") as file:
            voice_style = json.load(file)

        ttl_data = np.asarray(voice_style["style_ttl"]["data"], dtype=np.float32).flatten()
        ttl_style[index] = ttl_data.reshape(ttl_dims[1], ttl_dims[2])

        dp_data = np.asarray(voice_style["style_dp"]["data"], dtype=np.float32).flatten()
        dp_style[index] = dp_data.reshape(dp_dims[1], dp_dims[2])

    return StyleTensor(ttl=ttl_style, dp=dp_style)
