"""Public SDK interface."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import soundfile as sf

from ._engine import AVAILABLE_LANGS, load_text_to_speech_engine, load_voice_style_tensors
from .assets import (
    DEFAULT_MODEL_ID,
    DEFAULT_MODEL_REVISION,
    DEFAULT_REPO_ID,
    ModelBundle,
    resolve_model_bundle,
)
from .exceptions import ValidationError, VoiceStyleNotFoundError

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class VoiceStyle:
    """Reference to a voice style JSON file."""

    name: str
    path: Path


@dataclass
class SynthesisResult:
    """Audio returned by a synthesis request."""

    audio: np.ndarray
    sample_rate: int
    duration_seconds: float
    text: str
    lang: str
    voice_name: str

    def save(self, path: str | Path) -> Path:
        destination = Path(path).expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        sf.write(destination, self.audio, self.sample_rate)
        return destination


class TTS:
    """High-level BlitzTTS SDK entrypoint."""

    def __init__(
        self,
        *,
        model: str = DEFAULT_MODEL_ID,
        repo_id: str | None = DEFAULT_REPO_ID,
        model_revision: str | None = DEFAULT_MODEL_REVISION,
        model_dir: str | Path | None = None,
        cache_dir: str | Path | None = None,
        auto_download: bool = True,
        providers: Sequence[str] | None = None,
        token: str | None = None,
        bundle_url: str | None = None,
        bundle_sha256: str | None = None,
        bundle_sha256_url: str | None = None,
    ):
        self.model = model
        self.repo_id = repo_id or DEFAULT_REPO_ID
        self.model_revision = model_revision
        self.bundle: ModelBundle = resolve_model_bundle(
            model=model,
            model_dir=model_dir,
            auto_download=auto_download,
            repo_id=self.repo_id,
            model_revision=model_revision,
            cache_dir=cache_dir,
            token=token,
            bundle_url=bundle_url,
            bundle_sha256=bundle_sha256,
            bundle_sha256_url=bundle_sha256_url,
        )
        self._engine = load_text_to_speech_engine(self.bundle.onnx_dir, providers=providers)
        self.sample_rate = self._engine.sample_rate
        self.available_languages = tuple(AVAILABLE_LANGS)
        self._voice_cache: dict[Path, object] = {}

    @property
    def assets_dir(self) -> Path:
        return self.bundle.assets_dir

    @property
    def voice_styles_dir(self) -> Path:
        return self.bundle.voice_styles_dir

    def list_voices(self) -> list[str]:
        return sorted(path.stem for path in self.voice_styles_dir.glob("*.json"))

    def get_voice_style(
        self,
        *,
        voice_name: str | None = None,
        path: str | Path | None = None,
    ) -> VoiceStyle:
        if (voice_name is None) == (path is None):
            raise ValidationError("Provide exactly one of 'voice_name' or 'path'.")

        if path is not None:
            style_path = Path(path).expanduser().resolve()
        else:
            style_path = (self.voice_styles_dir / f"{voice_name}.json").resolve()

        if not style_path.is_file():
            raise VoiceStyleNotFoundError(f"Voice style not found: {style_path}")

        return VoiceStyle(name=style_path.stem, path=style_path)

    def _style_tensor(self, voice_style: VoiceStyle):
        cached = self._voice_cache.get(voice_style.path)
        if cached is None:
            cached = load_voice_style_tensors([voice_style.path])
            self._voice_cache[voice_style.path] = cached
        return cached

    def _resolve_voice(self, voice: str | VoiceStyle | None) -> VoiceStyle:
        if voice is None:
            return self.get_voice_style(voice_name="M1")

        if isinstance(voice, VoiceStyle):
            return voice

        return self.get_voice_style(voice_name=voice)

    def synthesize(
        self,
        text: str,
        *,
        voice: str | VoiceStyle | None = None,
        lang: str = "en",
        steps: int = 5,
        speed: float = 1.05,
        silence_duration: float = 0.3,
    ) -> SynthesisResult:
        voice_style = self._resolve_voice(voice)
        style_tensor = self._style_tensor(voice_style)
        wav, durations = self._engine(
            text,
            lang,
            style_tensor,
            total_step=steps,
            speed=speed,
            silence_duration=silence_duration,
        )
        duration = float(durations[0])
        audio = wav[0, : int(self.sample_rate * duration)].astype(np.float32)
        return SynthesisResult(
            audio=audio,
            sample_rate=self.sample_rate,
            duration_seconds=duration,
            text=text,
            lang=lang,
            voice_name=voice_style.name,
        )

    def synthesize_batch(
        self,
        texts: Sequence[str],
        *,
        voices: Sequence[str | VoiceStyle] | str | VoiceStyle = "M1",
        langs: Sequence[str] | str = "en",
        steps: int = 5,
        speed: float = 1.05,
    ) -> list[SynthesisResult]:
        if not texts:
            raise ValidationError("texts must contain at least one item.")

        text_list = list(texts)

        if isinstance(voices, (str, VoiceStyle)):
            voice_items: Iterable[str | VoiceStyle] = [voices] * len(text_list)
        else:
            voice_items = voices

        if isinstance(langs, str):
            lang_list = [langs] * len(text_list)
        else:
            lang_list = list(langs)

        voice_list = [self._resolve_voice(voice) for voice in voice_items]
        if len(voice_list) != len(text_list):
            raise ValidationError("voices must match the number of texts.")
        if len(lang_list) != len(text_list):
            raise ValidationError("langs must match the number of texts.")

        style_tensor = load_voice_style_tensors([voice.path for voice in voice_list])
        wav, durations = self._engine.batch(
            text_list,
            lang_list,
            style_tensor,
            total_step=steps,
            speed=speed,
        )

        results: list[SynthesisResult] = []
        for index, text in enumerate(text_list):
            duration = float(durations[index])
            audio = wav[index, : int(self.sample_rate * duration)].astype(np.float32)
            results.append(
                SynthesisResult(
                    audio=audio,
                    sample_rate=self.sample_rate,
                    duration_seconds=duration,
                    text=text,
                    lang=lang_list[index],
                    voice_name=voice_list[index].name,
                )
            )

        return results

    def save_audio(
        self,
        audio: SynthesisResult | np.ndarray,
        path: str | Path,
        *,
        sample_rate: int | None = None,
    ) -> Path:
        if isinstance(audio, SynthesisResult):
            return audio.save(path)

        array = np.asarray(audio)
        if array.ndim == 2 and array.shape[0] == 1:
            array = array[0]
        if array.ndim != 1:
            raise ValidationError("save_audio expects a mono waveform array.")

        destination = Path(path).expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        sf.write(destination, array.astype(np.float32), sample_rate or self.sample_rate)
        return destination
