"""Command-line entrypoint for the BlitzTTS SDK."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from . import TTS
from .assets import DEFAULT_MODEL_REVISION, DEFAULT_REPO_ID


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="blitz-tts", description="BlitzTTS Python SDK CLI")
    parser.add_argument("text", nargs="?", help="Text to synthesize")
    parser.add_argument("--voice", default="M1", help="Voice name, for example M1 or F4")
    parser.add_argument("--lang", default="en", help="Language code")
    parser.add_argument("--steps", type=int, default=5, help="Number of denoising steps")
    parser.add_argument("--speed", type=float, default=1.05, help="Speech speed multiplier")
    parser.add_argument(
        "--out",
        default="output.wav",
        help="Destination WAV path when synthesizing text",
    )
    parser.add_argument(
        "--model-dir",
        default=None,
        help="Local BlitzTTS asset bundle directory",
    )
    parser.add_argument(
        "--cache-dir",
        default=None,
        help="Cache directory for downloaded assets",
    )
    parser.add_argument(
        "--repo-id",
        default=DEFAULT_REPO_ID,
        help="Override the Hugging Face repository used for model downloads",
    )
    parser.add_argument(
        "--model-revision",
        default=DEFAULT_MODEL_REVISION,
        help="Pinned Hugging Face revision or tag used when downloading raw model files",
    )
    parser.add_argument(
        "--bundle-url",
        default=None,
        help="Direct .zip or .tar.gz asset bundle URL or local archive path",
    )
    parser.add_argument(
        "--bundle-sha256",
        default=None,
        help="Expected SHA256 checksum for the asset bundle archive",
    )
    parser.add_argument(
        "--bundle-sha256-url",
        default=None,
        help="URL or file path for a checksum sidecar file that contains the bundle SHA256",
    )
    parser.add_argument(
        "--token",
        default=None,
        help="Auth token for private model sources or gated Hugging Face repositories",
    )
    parser.add_argument(
        "--no-auto-download",
        action="store_true",
        help="Disable automatic model download",
    )
    parser.add_argument(
        "--list-voices",
        action="store_true",
        help="List all available voices and exit",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable SDK logging",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    tts = TTS(
        repo_id=args.repo_id,
        model_revision=args.model_revision,
        model_dir=args.model_dir,
        cache_dir=args.cache_dir,
        auto_download=not args.no_auto_download,
        token=args.token,
        bundle_url=args.bundle_url,
        bundle_sha256=args.bundle_sha256,
        bundle_sha256_url=args.bundle_sha256_url,
    )

    if args.list_voices:
        for voice_name in tts.list_voices():
            print(voice_name)
        return 0

    if not args.text:
        parser.error("text is required unless --list-voices is used")

    result = tts.synthesize(
        args.text,
        voice=args.voice,
        lang=args.lang,
        steps=args.steps,
        speed=args.speed,
    )
    destination = result.save(Path(args.out))
    print(destination)
    return 0
