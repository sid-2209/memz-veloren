"""SDK exception hierarchy."""


class BlitzTTSError(Exception):
    """Base exception for all SDK errors."""


class ConfigurationError(BlitzTTSError):
    """Raised when the SDK is misconfigured."""


class ModelNotFoundError(BlitzTTSError):
    """Raised when model assets cannot be located."""


class DownloadError(BlitzTTSError):
    """Raised when downloading model assets fails."""


class VoiceStyleNotFoundError(BlitzTTSError):
    """Raised when a requested voice style cannot be found."""


class ValidationError(BlitzTTSError):
    """Raised when the input payload is invalid."""
